# BakaMart — E-commerce Prototype

Mobile-first frontend prototype for a digital streaming-subscription storefront.

## Included
- Responsive homepage and product catalogue
- Demo products and clearly labelled demo pricing
- Search and category filters
- Cart with quantity controls and estimated totals
- Demo checkout form (no payment processing)
- WhatsApp order flow placeholder (no messages sent until configured)
- Basic Malay/English toggle
- GitHub Pages workflow

## Important before launch
This is a frontend-only prototype. Do not treat demo products or prices as real offers.
- Replace demo items only with subscriptions/accounts that you are legally authorised to resell.
- Configure the official business WhatsApp number in `app.js` before enabling order links.
- Integrate a payment provider server-side before accepting real payments. Never collect card details in this static site.
- Add privacy, refund, terms, and delivery policies.
- Do not distribute shared accounts or credentials unless the provider explicitly authorises it.

## Test locally
Open `index.html` in a browser. For best results, use a local static server.

## Deploy to GitHub Pages
The workflow in `.github/workflows/pages.yml` deploys the repository root when pushed to `main`. In repository Settings > Pages, set Source to GitHub Actions.
